#ifndef SORT_BY_NAME_H
#define SORT_BY_NAME_H
#include <iostream>
#include <string>
#include "animal.h"
#include "vegie.h"
#include "hunter.h"
#include "zoo.h"

class sort_by_name{
    public:
    
    static void sort(animal **animals,int n);	// sorts the array of n animals into ascending order using their animalIDs
};
#endif