#include <iostream>
#include <string>
#include "animal.h"
#include "vegie.h"
#include "hunter.h"
#include "zoo.h"
using namespace std;
int main(){

    return 0;
}