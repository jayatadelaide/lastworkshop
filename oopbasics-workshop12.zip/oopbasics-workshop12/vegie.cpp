#include <iostream>
#include <string>
#include "animal.h"
#include "vegie.h"

int vegie::nextID=100;
vegie::vegie(){
    
}
vegie::vegie(string n,int v){
    animalID=nextID;
    nextID++;
    name=n;
    volume=v;
};      // create a vegie with name n and body volume v
string vegie::get_name(){
    return "Safe: "+name;
};
string vegie::set_name(string j){
    name=j;
    return name;
};
string vegie::get_favourite_food(){
    return favourite_food;
}
string vegie::set_favourite_food(string y){
    favourite_food=y;
    return favourite_food;
};
