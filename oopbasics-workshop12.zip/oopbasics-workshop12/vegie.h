#ifndef VEGIE_H 
#define VEGIE_H 
#include <iostream>
#include <string>
#include "animal.h"
using namespace std;
class vegie:public animal{
public:
vegie();
vegie(string n,int v);      // create a vegie with name n and body volume v
string get_name();
string set_name(string j);
string get_favourite_food();
string set_favourite_food(string y);
private:
string favourite_food="grass";     // the vegie's favourite food, initialise to "grass"
static int nextID;

};
#endif
