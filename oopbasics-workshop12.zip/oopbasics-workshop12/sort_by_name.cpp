#include <iostream>
#include <string>
#include "animal.h"
#include "vegie.h"
#include "hunter.h"
#include "zoo.h"
#include "sort_by_name.h"
#include <algorithm>

using namespace std;
void sort_by_name::sort(animal **animals, int n) {
    animal *temp;
    for(int i = 0; i < n; ++i) {
        for(int j = 0; j < n-1; ++j) {
            if(animals[j]->get_name() > animals[j+1]->get_name()) {
                temp = animals[j];
                animals[j] = animals[j+1];
                animals[j+1] = temp;
            }
        }
    }
}