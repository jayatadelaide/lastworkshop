
#include <iostream>
#include <string>
#include "hunter.h"
using namespace std;
int hunter::nextID=1000;
    hunter::hunter(){

    }
    hunter::hunter(string n, int v){

        animalID=nextID;
        nextID++;
        name=n;
        volume=v;
        
    } 
    string hunter::get_name(){
        return "Hunter: "+name;
    }
    string hunter::set_name(string na){
        name=na;
        return name;
    }
    int hunter::get_kills(){
        return kills;
    }
    int hunter::set_kills(int k){
        kills=k;
        return kills;
    }

