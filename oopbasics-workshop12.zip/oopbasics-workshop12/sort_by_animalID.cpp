#include <iostream>
#include <string>
#include "animal.h"
#include "vegie.h"
#include "hunter.h"
#include "zoo.h"
#include "sort_by_animalID.h"
#include <algorithm>

using namespace std;
void sort_by_animalID::sort(animal **animals,int n)
{
animal* temp;
int i,j; //bubble sort is used
for (i = 0; i < n-1; i++){
    // Last i elements are already in place
for (j = 0; j < n-i-1; j++){
            if(animals[j]->get_animalID() > animals[j+1]->get_animalID()) {
                temp = animals[j];
                animals[j] = animals[j+1];
                animals[j+1] = temp;
            }
}

}


}