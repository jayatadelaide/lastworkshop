#include <iostream>
#include <string>
#include "hunter.h"
using namespace std;

int main(){
    hunter h("Cheetah",1);
    cout<<h.get_name()<<h.get_kills();
    return 0;
}