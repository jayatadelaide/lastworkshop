#include <iostream>
#include <string>
#include "animal.h"
#include "vegie.h"
using namespace std;
int main(){
    vegie v;
    cout<<v.get_favourite_food();
    return 0;
}