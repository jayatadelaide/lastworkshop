#ifndef ANIMAL_H 
#define ANIMAL_H 
#include <iostream>
#include <string>
using namespace std;
class animal{
    public:
    animal();
    animal(string n, int v);  // creates an animal with name n and body volume v.
                                 // animals are allocated a unique ID on creation
    string name;              // the animal's name
    int animalID;             // the animal's unique ID
    int volume;               // the volume of the animal's body
    //set methods
    string set_name(string j);
    int set_volume(int vol);
    //get methods
    virtual string get_name()=0;
    int get_animalID();
    int get_volume();
};
#endif