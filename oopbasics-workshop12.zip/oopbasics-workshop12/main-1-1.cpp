#include <iostream>
#include <string>
#include "animal.h"
using namespace std;

class bat:public animal{
    public:
    string get_name(){
    return name;
    }
};
int main(){
    bat b;

    return 0;
}