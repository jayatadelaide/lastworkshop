#include <iostream>
#include <string>
#include "animal.h"
using namespace std;

 animal::animal(){
    
 }
 animal::animal(string n, int v){}
     //set methods
    string animal::set_name(string j){
        name=j;
    return name;
    }
    int animal::set_volume(int vol){
        volume=vol;
        return volume;
    }
    //get methods
    int animal::get_animalID(){
        return animalID;
    }
    int animal::get_volume(){
        return volume;
    }