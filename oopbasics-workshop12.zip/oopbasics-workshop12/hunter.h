#ifndef HUNTER_H
#define HUNTER_H
#include <iostream>
#include <string>
#include "animal.h"
using namespace std;
class hunter: public animal{
    public:
    hunter();
    hunter(string n, int v);  // create a hunter with name n and body volume v
    //methods
    string get_name();
    string set_name(string na);
    int get_kills();
    int set_kills(int k);
    private:
    string name;
    int kills=0;               // how many kills have been recorded, initialised to 0
    static int nextID;
    
};
#endif