#ifndef ZOO_H
#define ZOO_H
#include <iostream>
#include <string>
#include "animal.h"
#include "vegie.h"
#include "hunter.h"

class zoo{
    public:
    zoo(){};
zoo(string n,int cows,int lions);      // create a zoo with the given number of cows and lions
string get_name();
int get_number_of_animals();
animal** get_animals();
private:
string name ;                          // the zoo's name
int number_of_animals ;                // the number of animals in the zoo
animal **animals ;                      // the zoo's animals
};
#endif